from pyhoroscope import Horoscope

